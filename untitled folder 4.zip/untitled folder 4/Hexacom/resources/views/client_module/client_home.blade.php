<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Service Engineer Dashboard</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="/css/sb-admin-2.min.css" rel="stylesheet">

  <!-- Vendor CSS -->
  

  <script type="text/javascript" src="js/date_time.js"></script>
  <!-- Specific Page Vendor CSS -->
  <link rel="stylesheet" href="/vendor/jquery-ui/css/ui-lightness/jquery-ui-1.10.4.custom.css" />
  <link rel="stylesheet" href="/vendor/bootstrap-multiselect/bootstrap-multiselect.css" />
  <link rel="stylesheet" href="/vendor/morris/morris.css" />  

  <!-- Theme CSS -->
  <link rel="stylesheet" href="/stylesheets/theme.css" />

  <!-- Skin CSS -->
  <link rel="stylesheet" href="/stylesheets/skins/default.css" />

  <!-- Theme Custom CSS -->
  <link rel="stylesheet" href="/stylesheets/theme-custom.css">

  <!-- Head Libs -->
  <script src="/vendor/modernizr/modernizr.js"></script>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/service_engineer">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Hi there! </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      @include('client_module.includes.nav')


      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">

      </div>


      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
            <span id="date_time"></span>
            <script type="text/javascript">window.onload = date_time('date_time');</script>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->

            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>

            <!-- Nav Item - User Information -->
            @include('client_module.includes.user_info')

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
      <div class="row">
        <div class="container-fluid">
          <section class="panel panel-transparent">
            <div class="panel-body">
              <section class="panel panel-group">
                <header class="panel-heading bg-primary">
                  <div class="widget-profile-info">
                    <div class="profile-picture">
                      <img src="/img/uploads/avatars/{{$currentUser['profile_pic']}}">
                    </div>
                    <div class="profile-info">
                      <h4 class="name text-semibold">{{$currentUser['name']}}</h4>
                      <h5 class="role">{{$currentUser['type']}}</h5>
                      <div class="profile-footer">
                        <a href='/profile'>Edit Profile</a> | <a href='/reports'>Download Reports</a>
                      </div>
                    </div>
                  </div>
                </header>
              </section>
            </div>
          </section>
        </div>
      </div>
        <!-- /.container-fluid -->
<div class="row">
  <div class="container-fluid">
    <div class="col-md-12 col-lg-6 col-xl-6">
      <section class="panel panel-featured-left panel-featured-primary">
        <div class="panel-body">
          <div class="widget-summary">
            <div class="widget-summary-col widget-summary-col-icon">
              <div class="summary-icon bg-primary">
                <i class="fa fa-life-ring"></i>
              </div>
            </div>
            <div class="widget-summary-col">
              <div class="summary">
                <h4 class="title">Total Service</h4>
                <div class="info">
                  <strong class="amount">{{$allServiceCount}}</strong>
                </div>
              </div>
              <div class="summary-footer">
                <a href="/allservices" class="text-muted text-uppercase">View All</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <div class="col-md-12 col-lg-6 col-xl-6">
      <section class="panel panel-featured-left panel-featured-primary">
        <div class="panel-body">
          <div class="widget-summary">
            <div class="widget-summary-col widget-summary-col-icon">
              <div class="summary-icon bg-primary">
                <i class="fa fa-life-ring"></i>
              </div>
            </div>
            <div class="widget-summary-col">
              <div class="summary">
                <h4 class="title">My Services</h4>
                <div class="info">
                  <strong class="amount">{{$myServiceCount}}</strong>
                </div>
              </div>
              <div class="summary-footer">
                <a href="/myservices" class="text-muted text-uppercase">View All</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>  
    <div class="col-md-12 col-lg-6 col-xl-6">
      <section class="panel panel-featured-left panel-featured-primary">
        <div class="panel-body">
          <div class="widget-summary">
            <div class="widget-summary-col widget-summary-col-icon">
              <div class="summary-icon bg-primary">
                <i class="fa fa-life-ring"></i>
              </div>
            </div>
            <div class="widget-summary-col">
              <div class="summary">
                <h4 class="title">Unclaimed Items</h4>
                <div class="info">
                  <strong class="amount">{{$unclaimedCount}}</strong>
                </div>
              </div>
              <div class="summary-footer">
                <a href="/notifications" class="text-muted text-uppercase">View All</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <div class="col-md-12 col-lg-6 col-xl-6">
      <section class="panel panel-featured-left panel-featured-tertiary">
        <div class="panel-body">
          <div class="widget-summary">
            <div class="widget-summary-col widget-summary-col-icon">
              <div class="summary-icon bg-tertiary">
                <i class="fa fa-shopping-cart"></i>
              </div>
            </div>
            <div class="widget-summary-col">
              <div class="summary">
                <h4 class="title">Total Inventory</h4>
                <div class="info">
                  <strong class="amount">{{$inventoriesCount}}</strong>
                </div>
              </div>
              <div class="summary-footer">
                <a href="/inventory" class="text-muted text-uppercase">View All</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

  </div>
</div>





      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


    <!-- Bootstrap core JavaScript-->
  <script src="/vendor/jquery/jquery.min.js"></script>
  <script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="/js/sb-admin-2.min.js"></script>

</body>

</html>
