<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Other Brand</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <script type="text/javascript" src="js/date_time.js"></script>

  <link href="twitter-bootstrap/2.3.2/css/bootstrap-combined.css" rel="stylesheet" id="bootstrap-css">
  <script src="twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
  <script src="twitter-bootstrap/1.11.1/js/jquery-1.11.1.min.js"></script>

  <!--forms-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/css/bootstrap.min.css'>

    <link rel="stylesheet" href="css/style.css">

    <style>
      * {
  .border-radius(0) !important;
}

#field {
    margin-bottom:20px;
}
    </style>




</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Hi there! </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
   <li class="nav-item">
        <a class="nav-link" href="index.html">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="services.html">
          <i class="fas fa-fw fa-table"></i>
          <span>Services</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="addservices.html">
          <i class="fas fa-fw fa-table"></i>
          <span>Add Services</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="statusofsales.html">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Status of Sales</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="inventory.html">
          <i class="fas fa-fw fa-folder"></i>
          <span>Inventory</span></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="customize.html">
          <i class="fas fa-fw fa-wrench"></i>
          <span>Customize your PC</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notifications.html">
          <i class="fas fa-fw fa-bell"></i>
          <span>Notifications</span></a>
      </li>

     
      <!-- Heading -->
      <div class="sidebar-heading">
        
      </div>

      <!-- Nav Item - Tables -->
      

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
       <span id="date_time"></span>
            <script type="text/javascript">window.onload = date_time('date_time');</script>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            

            

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Ed Caluag</span>
                <img class="img-profile rounded-circle" src="img/anonymous.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="Profile.html">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="activity-log.html">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
          <div class="container text-right">
          <a href="addservices.html"><button type="button" class="btn btn-primary d-inline">&laquo; Back</button></a>
        </div>
        <br>


          <!-- Page Heading -->
          <div class="card">
            <h5 class="card-header">Other Brand</h5>
            <div class="card-body-forOthers"> 


              <div class="form-row">
                  <div class="form-group col-md-5">
                    <label for="inputState">Date</label>
                    <div class="input-group">
                      <input type="date" data-plugin-datepicker id="inputDate" class="form-control">
                    </div>
                  </div>
                </div>

                <!-- FULL NAME -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">First Name</label>
                    <div class="input-group">
                      <input type="firstname" class="form-control" id="inputLastname" placeholder="First name">
                    </div>
                  </div>

                  <div class="form-group col-md-6">
                    <label for="inputState">Last Name</label>
                    <div class="input-group">
                      <input type="lastname" class="form-control" id="inputLastname" placeholder="Last name">
                    </div>
                  </div>
                </div>

                <!-- CONTACT NO -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">Phone</label>
                      <div class="input-group">
                        <input id="phone" data-plugin-maxlength maxlength="11" data-plugin-masked-input data-input-mask="09999999999" placeholder="09532454000" class="form-control" id="inputPhone">
                      </div>
                  </div>
                </div>

                <!-- SERVICE ENGINEER -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">Address</label>
                    <div class="input-group">
                      <input type="address" class="form-control" id="inputAddress" placeholder="123 Main St.">
                    </div>
                  </div>
                </div>

                <!-- ITEM -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputItem">Item</label>
                    <select id="inputItem" class="form-control">
                      <option selected>Choose...</option>
                      <option>...</option>
                    </select>
                  </div>
                </div>


                <!-- BRAND -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputBrand">Brand</label>
                    <select id="inputBrand" class="form-control">
                      <option selected>Choose...</option>
                      <option>...</option>
                    </select>
                  </div>
                </div>

                <!-- TYPE -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">Type</label>
                    <div class="input-group">
                      <input type="type" class="form-control" id="inputType" placeholder="Aspire">
                    </div>
                  </div>
                </div>

                <!-- MODEL -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">Model</label>
                    <div class="input-group">
                      <input type="model" class="form-control" id="inputModel" data-plugin-maxlength maxlength="30" placeholder="ES-2468951">
                    </div>
                  </div>
                </div>

                <!-- SERIAL NUMBER -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">Serial Number</label>
                    <div class="input-group">
                      <input type="serial-number" class="form-control" id="inputSerialNumber" data-plugin-maxlength maxlength="15" placeholder="54ABD2468951">
                    </div>
                  </div>
                </div>




                <!-- ACCESSORIES -->
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">Accessories</label>
                    <div class="input-group">
                      <input type="accessories" class="form-control" id="inputAccessories" data-plugin-maxlength maxlength="30" placeholder="charger">
                    </div>
                  </div>
                </div>


                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputState">PSU</label>
                    <select id="inputState" class="form-control">
                      <option selected>Choose...</option>
                      <option>...</option>
                    </select>
                  </div>
                </div>

                <div class="container">
                  <div class="row">
                    <input type="hidden" name="count" value="1" />
                    <div class="control-group" id="fields">
                      <label class="control-label" for="field1">Defects</label>
                      <div class="controls" id="profs">
                        <form class="input-append">
                          <div id="field"><input autocomplete="off" class="input" id="field1" name="prof1" type="text" placeholder="Type Defects" data-items="8"/><button id="b1" class="btn add-more" type="button">+</button>
                          </div>
                        </form>
                        <small>Press + to add another form field</small>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
              <br>
              <div class="text-right">
                <a href="#" class="btn btn-primary">Done</a>
                <a href="#" class="btn btn-primary">Cancel</a>
              </div>
              <br>
              <br>
            </div>
          </div>




          
















        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!--forms bootstrap-->

  <script src='http://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places'></script>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/geocomplete/1.7.0/jquery.geocomplete.min.js'></script>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-beta/js/bootstrap.min.js'></script>

  <!-- JS -->
    <script src="vendor/bootstrap/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

  

  <script  src="js/index.js"></script>


</body>

</html>
